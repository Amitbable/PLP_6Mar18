package com.cg.admin.dto;

public class Airport 
{
	private String airportName;
	private String abbreviation;
	private String locationId;
	public Airport() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Airport(String airportName, String abbreviation, String locationId) {
		super();
		this.airportName = airportName;
		this.abbreviation = abbreviation;
		this.locationId = locationId;
	}
	public String getAirportName() {
		return airportName;
	}
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}
	public String getAbbreviation() {
		return abbreviation;
	}
	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	@Override
	public String toString() {
		return "Airport [airportName=" + airportName + ", abbreviation="
				+ abbreviation + ", locationId=" + locationId + "]";
	}
	

}
