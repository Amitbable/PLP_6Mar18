package com.cg.admin.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.admin.dto.BookingInformation;
import com.cg.admin.dto.FlightInformation;
import com.cg.admin.service.IBookingService;

@Controller
public class MyController 
{	

	@Autowired
	IBookingService bookingservice;

	@RequestMapping(value="all", method=RequestMethod.GET)
	public String getAll(Model model)
	{
		//model.addAttribute("my", new FlightInformation());
		return "home";
	}

	@RequestMapping(value="check", method=RequestMethod.POST)
	public String validateAdmin(@ModelAttribute("my") FlightInformation fi)
	{

		return "loginsuccess";

	}

	@RequestMapping(value="insertdata", method=RequestMethod.POST)
	public String validateAdmin1(@ModelAttribute("my") FlightInformation fi)
	{
		bookingservice.addFlight(fi);
		return "insertSuccess";

	}

	@RequestMapping(value="customer", method=RequestMethod.GET)
	public String customerWelcome(Model model)
	{
		List<String> myList = bookingservice.getAllSourceCities();
		List<String> myList1 = bookingservice.getAllDestinationCities();
		model.addAttribute("my",new  FlightInformation());
		model.addAttribute("source",myList);
		model.addAttribute("destination", myList1);
		return "searchFlights";
	}

	@RequestMapping(value="showFlights", method=RequestMethod.GET)
	public ModelAndView searchFlight(@ModelAttribute("my") FlightInformation fi)
	{
		System.out.println(fi.getDeptCity());
		List<FlightInformation> myList = bookingservice.getAllFlights(fi.getDeptCity(), fi.getArrCity());
		//		model.addAttribute("my",new  FlightInformation());
		//		model.addAttribute("fInfo",myList);
		return new ModelAndView("viewFlights", "fInfo", myList);
	}


	@RequestMapping(value="book",  method=RequestMethod.GET)
	public ModelAndView bookFlight(@RequestParam("id") int fNo,@ModelAttribute("my") BookingInformation bi)
	{
		System.out.println(fNo);
		FlightInformation fi=bookingservice.getParticularFlight(fNo);
		System.out.println(fi.getDeptCity());

		return new ModelAndView("bookFlight", "temp", fi);

	}


	@RequestMapping(value="bookvalidate",  method=RequestMethod.POST)
	public ModelAndView bookFlight1(@RequestParam("id") int fNo,@ModelAttribute("my") BookingInformation bi)
	{
		System.out.println(fNo);
		double tf=0.0;
		String s=null;
		FlightInformation fi=bookingservice.getParticularFlight(fNo);
		bi.setFlightNo(fNo);
		bi.setSrcCity(fi.getDeptCity());
		bi.setDestCity(fi.getArrCity());
		/*//		System.out.println(fi.getDeptCity());
		if(bi.getClassType().equalsIgnoreCase("business"))
				{
					 tf = fi.getBussSeatsFare()*bi.getNoOfPassengers();
				}
		else 
		{
			 tf = fi.getFirstSeatsFare()*bi.getNoOfPassengers();
		}
		bi.setFlightNo(fNo);
		bi.setTotalFare(tf);
		System.out.println(tf);
		//return new ModelAndView("bookFlight1", "total", bi);
		 */
		if(bi.getClassType().equalsIgnoreCase("business"))
		{
			tf = fi.getBussSeatsFare()*bi.getNoOfPassengers();
			System.out.println(fi.getAvlBussSeats());
			if(fi.bookBussSeats(bi.getNoOfPassengers()))
			{
				int upLim=fi.getBussSeats()-fi.getAvlBussSeats();
				int lowLim=(upLim-bi.getNoOfPassengers())+1;
				int i;
				s="Your Seats are: "+lowLim;
				for(i=lowLim+1;i<=upLim;i++)
				{
					s=s+","+i;
				}
				System.out.println(s);
				bi.setSeatNumber(s);
				tf = (Double) (bi.getNoOfPassengers()*fi.getBussSeatsFare());
				System.out.println("Total Fare for this journey is: "+tf);
				bi.setTotalFare(tf);
				bookingservice.bookTicket(bi);
			}
			else
			{
				if(bi.getNoOfPassengers()>5)
				{
					return new ModelAndView("noSeats","message","Sorry, only 5 Passengers per booking ID according to government norms");
				}
				else if(fi.getAvlBussSeats()<bi.getNoOfPassengers())
				{
					System.out.println("Sorry. No Seats Available");

					return new ModelAndView("noSeats","message","Sorry. Please select equal or less than available seats");
				}
				else
				{
					return new ModelAndView("noSeats","message","Sorry, No seats available for this circle");
				}
			}
		}

		else 
		{
			tf = fi.getFirstSeatsFare()*bi.getNoOfPassengers();
			if(fi.bookFirstSeats(bi.getNoOfPassengers()))
			{
				int upLim=fi.getFirstSeats()-fi.getAvlFirstSeats();
				int lowLim=(upLim-bi.getNoOfPassengers())+1;
				int i;
				s=" "+lowLim;
				for(i=lowLim+1;i<=upLim;i++)
				{
					s=s+","+i;
				}
				System.out.println("Your seats are" + s);
				bi.setSeatNumber(s);
				tf = (Double) (bi.getNoOfPassengers()*fi.getFirstSeatsFare());
				System.out.println("Total Fare for this journey is: "+tf);
				bi.setTotalFare(tf);
				bookingservice.bookTicket(bi);
			}
			else

			{	
				if(bi.getNoOfPassengers()>5)
				{
					return new ModelAndView("noSeats","message","Sorry, only 5 Passengers per booking ID according to government norms");
				}
				else if(fi.getAvlFirstSeats()<bi.getNoOfPassengers())
				{
					System.out.println("Sorry. No Seats Available");

					return new ModelAndView("noSeats","message","Sorry. Please select equal or less than available seats");
				}
				else
				{
					return new ModelAndView("noSeats","message","Sorry, No seats available for this circle");
				}
			}
		}

		if(bookingservice.updateFlightSeatsCNF(fi)){
			System.out.println("Successfully Booked");

		}
		else {
			System.out.println("Booking Failed...");

		}


		return new ModelAndView("viewTicket", "all", bi);
	}




	@RequestMapping(value="delete",  method=RequestMethod.GET)
	public ModelAndView deleteTicket(@RequestParam("id") int bId,@RequestParam("id1") int fNo)
	{
		System.out.println(bId);
		System.out.println(bId);
		System.out.println(bId);
	FlightInformation fi=bookingservice.getParticularFlight(fNo);
	BookingInformation bi=bookingservice.getParticularTicket(bId);
	
	String classType1=bi.getClassType();
	if(classType1.equalsIgnoreCase("Economy"))
	{
		if(fi.cancelFirstSeats(bi.getNoOfPassengers()))
		{
			bookingservice.deleteTicket(bId);
			System.out.println("Your tickets have been cancelled with refund amount of "+(bi.getTotalFare()-500));
		}
		else
		{
			System.out.println("Sorry!!!. Cancellation failed");
		}
	}
	if(classType1.equalsIgnoreCase("Business"))
	{
		if(fi.cancelBussSeats(bi.getNoOfPassengers()))
		{
			bookingservice.deleteTicket(bId);
			System.out.println("Your tickets have been cancelled with refund amount of "+(bi.getTotalFare()-1000));
		}
		else
		{
			System.out.println("Sorry!!!. Cancellation failed");
		}
	}
	if(bookingservice.updateFlightSeatsCNF(fi))
	{
		
		
		System.out.println("Successfully Cancelled");
	}
	else
	{
		System.out.println("Cancellation Failed... Please call us");
		return new ModelAndView("Failure", "message","Cancellation Failed... Please call us" );
	}
	
		return new ModelAndView("noSeats", "message","Your tickets have been cancelled with refund amount of "+(bi.getTotalFare()-1000) );
	}




	/*@RequestMapping(value="dobook",  method=RequestMethod.GET)
	public ModelAndView bookFlight2(@RequestParam("id") int fNo,@ModelAttribute("my") BookingInformation bi)
	{
		System.out.println(fNo);
		double tf=0.0;
		String s=null;
		FlightInformation fi=bookingservice.getParticularFlight(fNo);
		System.out.println(fi.getDeptCity());
		if(bi.getClassType().equalsIgnoreCase("business"))
				{
					 tf = fi.getBussSeatsFare()*bi.getNoOfPassengers();
					 System.out.println(fi.getAvlBussSeats());
						if(fi.bookBussSeats(bi.getNoOfPassengers()))
						{
							int upLim=fi.getBussSeats()-fi.getAvlBussSeats();
							int lowLim=(upLim-bi.getNoOfPassengers())+1;
							int i;
							s="Your Seats are: "+lowLim;
							for(i=lowLim+1;i<=upLim;i++)
							{
								s=s+","+i;
							}
							System.out.println(s);
							bi.setSeatNumber(s);
							tf = (Double) (bi.getNoOfPassengers()*fi.getBussSeatsFare());
							System.out.println("Total Fare for this journey is: "+tf);
						}
						else
						{
							System.out.println("Sorry. No Seats Available");
						}


				}
		else 
		{
			 tf = fi.getFirstSeatsFare()*bi.getNoOfPassengers();
				if(fi.bookFirstSeats(bi.getNoOfPassengers()))
				{
					int upLim=fi.getFirstSeats()-fi.getAvlFirstSeats();
					int lowLim=(upLim-bi.getNoOfPassengers())+1;
					int i;
					s=" "+lowLim;
					for(i=lowLim+1;i<=upLim;i++)
					{
						s=s+","+i;
					}
					System.out.println("Your seats are" + s);
					bi.setSeatNumber(s);
					tf = (Double) (bi.getNoOfPassengers()*fi.getFirstSeatsFare());
					System.out.println("Total Fare for this journey is: "+tf);
				}
				else
				{
					System.out.println("Sorry. No Seats Available");
				}

		}
		if(bookingservice.updateFlightSeatsCNF(fi)){
			System.out.println("Successfully Booked");

		}
		else {
			System.out.println("Booking Failed...");

		}


		return new ModelAndView("insertSuccess", "total", tf);
	}

	 */

}
