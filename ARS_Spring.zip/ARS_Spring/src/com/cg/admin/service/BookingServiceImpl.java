package com.cg.admin.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.admin.dao.IBookingDao;
import com.cg.admin.dto.BookingInformation;
import com.cg.admin.dto.FlightInformation;


@Service("bookingservice")
@Transactional
public class BookingServiceImpl implements IBookingService
{
	
	@Autowired
	IBookingDao bookingdao;
	
	@Override
	public int bookTicket(BookingInformation bi) 
	{
		
		return bookingdao.bookTicket(bi);
	}

	@Override
	public List<String> getAllSourceCities() 
	{
		return bookingdao.getAllSourceCities();
	}

	@Override
	public List<String> getAllDestinationCities() 
	{
		return bookingdao.getAllDestinationCities();
	}

	@Override
	public List<FlightInformation> getAllFlights(String src, String des) 
	{
		return bookingdao.getAllFlights(src, des);
	}

	@Override
	public FlightInformation getParticularFlight(int fNo) 
	{
		return bookingdao.getParticularFlight(fNo);
	}

	@Override
	public int addFlight(FlightInformation fi) 
	{
		return bookingdao.addFlight(fi);
	}
	
	@Override
	public boolean updateFlightSeatsCNF(FlightInformation fi)
			{
		return bookingdao.updateFlightSeatsCNF(fi);
	}

	@Override
	public BookingInformation getParticularTicket(int bId) {
		
		return bookingdao.getParticularTicket(bId);
	}

	@Override
	public void deleteTicket(int bId) 
	{
		bookingdao.deleteTicket(bId);
		
	}
	
	
}
