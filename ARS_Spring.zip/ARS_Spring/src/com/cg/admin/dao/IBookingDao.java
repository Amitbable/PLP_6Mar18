package com.cg.admin.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.admin.dto.BookingInformation;
import com.cg.admin.dto.FlightInformation;

public interface IBookingDao 
{
	
	public int bookTicket(BookingInformation bi);
	public List<String> getAllSourceCities();
	public List<String> getAllDestinationCities();
	public List<FlightInformation> getAllFlights(String src, String des);
	public FlightInformation getParticularFlight(int fNo);
	public int addFlight(FlightInformation fi);
	public boolean updateFlightSeatsCNF(FlightInformation fi);
	public BookingInformation getParticularTicket(int bId);
	public void deleteTicket(int bId);
}
